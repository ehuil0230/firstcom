/*公共配置文件，用于统一配置，实现政务外网和互联网的区分*/
const packsgeStatus = 'zwww'
// const packsgeStatus = 'hlw'
const baseUrl  = "cyfz-center/rest"

export default {
    packsgeStatus,
    baseUrl
}
