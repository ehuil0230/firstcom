<template>

</template>

<script>
    export default {
        name: "hygl"
    }
</script>

<style scoped>

</style>
