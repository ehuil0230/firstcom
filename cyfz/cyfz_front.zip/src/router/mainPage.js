export default [
    {
        path:'/search',
        name:'search',
        component:()=>import('@/views/mainPage/fullSearch')
    },
]
