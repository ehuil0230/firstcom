const logincenterUrl = '/qxgl-center';
const login =logincenterUrl+'/Mh001LoginCtrl/handleLogins'
const getLoginUser =logincenterUrl+'/Mh001LoginCtrl/getLoginUser'
const Qxgl002orgTree = logincenterUrl+'/Qxgl002OrgCtrl/queryOrgTreeBySjorgId'
export default {
    login,
    getLoginUser,
    Qxgl002orgTree
}
