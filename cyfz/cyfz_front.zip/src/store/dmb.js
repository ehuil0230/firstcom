export default {
    namespaced: true,
    state: {
        sjztList:[
            {
                code: "0",
                caption: "作废"
            },
            {
                code: "1",
                caption: "有效"
            },
            {
                code: "2",
                caption: "新增待审"
            },
            {
                code: "3",
                caption: "删除待审"
            }
        ]
    },
    mutations: {

    },
    actions: {

    }
}